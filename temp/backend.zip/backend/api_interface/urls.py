# Defines URL routes for the API interface views.

from django.urls import path

urlpatterns = [
    # empty for now, will be filled with other app URL includes
]